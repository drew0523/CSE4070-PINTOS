#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "threads/vaddr.h"

static void syscall_handler (struct intr_frame *);
void check_address(void* vaddr);

//usermemoryaccess구현!
void check_address(void* vaddr){
  //1. kernel 영역 2. NULL pointer 인 경우 예외처리
  struct thread *cur = thread_current();
  if(vaddr==NULL || is_kernel_vaddr(vaddr)){
    exit(-1);
  }
}

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}
 
static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  // printf("syscall# : %d!!\n",(int)*(char*)(f->esp));
  // hex_dump(f->esp,f->esp,300,true);
  //printf ("system call!\n");
  void *stack_pointer = f->esp;
  switch(*(uint32_t*)stack_pointer){
    case SYS_HALT:  //0
      //printf("SYS_HALT!!\n");
      halt();
      break;
    
    case SYS_EXIT:  //1
      //printf("SYS_EXIT!!\n");
      check_address(stack_pointer+4);
      exit(*(uint32_t*)(stack_pointer+4));
      break;
    
    case SYS_EXEC:  //2
      //printf("SYS_EXEC!!\n");
      check_address(stack_pointer+4);
      f->eax=exec((const char*)*(uint32_t*)(stack_pointer+4));
      break;
    
    case SYS_WAIT:  //3
      //printf("SYS_WAIT!!\n");
      check_address(stack_pointer+4);
      f->eax=wait(*(uint32_t*)(stack_pointer+4));
      break;

    case SYS_READ:  //8
      //printf("SYS_READ!!\n");
      check_address(stack_pointer+4);
      check_address(stack_pointer+8);
      check_address(stack_pointer+12);
      f->eax=read((int)*(uint32_t*)(stack_pointer+4),(void*)*(uint32_t*)(stack_pointer+8),(unsigned int)*(uint32_t*)(stack_pointer+12));
      break;

    case SYS_WRITE: //9
      //printf("SYS_WRITE!!\n");
      check_address(stack_pointer+4);
      check_address(stack_pointer+8);
      check_address(stack_pointer+12);
      f->eax=write((int)*(uint32_t*)(stack_pointer+4),(void*)*(uint32_t*)(stack_pointer+8),(unsigned int)*(uint32_t*)(stack_pointer+12));
      break;

    case SYS_FIBONACCI:
      check_address(stack_pointer+4);
      f->eax=fibonacci((int)*(uint32_t*)(stack_pointer+4));
      break;

    case SYS_MAX_OF_FOUR_INT:
      check_address(stack_pointer+4);
      check_address(stack_pointer+8);
      check_address(stack_pointer+12);
      check_address(stack_pointer+16);
      f->eax=max_of_four_int((int)*(uint32_t*)(stack_pointer+4),(int)*(uint32_t*)(stack_pointer+8),(int)*(uint32_t*)(stack_pointer+12),(int)*(uint32_t*)(stack_pointer+16));
      break;


  }
}

void halt(){
  shutdown_power_off();
}

void exit(int status){
  struct thread *cur = thread_current();
  printf("%s: exit(%d)\n",thread_name(),status);
  cur->exit_status=status;
  thread_exit();
}

tid_t exec(const char *cmd_line){
  return process_execute(cmd_line);
}

int wait(tid_t pid){
  return process_wait(pid);
}

//fd에서 size만큼 읽어와서 buffer에 저장
int read(int fd, void *buffer, unsigned int size){
  if (fd==0) {
    for (unsigned i = 0; i < size; i++) {
      *((uint8_t *)buffer + i) = input_getc();
    }
    return size;
  }
  return -1;
}

int write(int fd, void *buffer, unsigned int size){
  if(fd==1){
    putbuf(buffer,size);
    return size;
  }
  else{
    return -1;
  }
}

//additional.c 구현
int fibonacci(int n) {
  if(n==0) return 0;
  else if(n==1) return 1;
  else return fibonacci(n-1)+fibonacci(n-2);
}

int max_of_four_int(int a, int b, int c, int d) {
  int max=a;
  if(b>max) max=b;
  if(c>max) max=c;
  if(d>max) max=d;
  return max;
}